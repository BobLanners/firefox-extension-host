// Content script to interact with the Live Server website
console.log("Extension loaded on Live Server website!");
let NamesToHide = [] ;

chrome.storage.local.get("NamesToHide", (result) => {
    NamesToHide = result.NamesToHide || [];
    console.log("Loaded Names to hide:", NamesToHide);
});


// Function to find a table by its name and make its <thead> sticky
function makeTableHeaderSticky() {
    // Find the table with the specified name attribute
    const tables = document.querySelector('[class~="table"]');

    if (tables) {
        // Find the first <thead> inside the table
        const thead = tables.querySelector("thead");

        if (thead) {
            // Inject inline CSS to make the <thead> sticky
            thead.style.position = "sticky";
            thead.style.top = '100px';
            thead.style.zIndex = "1050";

        } else {
            console.log("No <thead> element found in the target table.");
        }
    } else {
        console.log(`No table found.`);
    }
}

function makeTableHeaderUnsticky() {
    // Find the table with the specified name attribute
    const tables = document.querySelector('[class~="table"]');

    if (tables) {
        // Find the first <thead> inside the table
        const thead = tables.querySelector("thead");

        if (thead) {
            // Inject inline CSS to make the <thead> unsticky
            thead.style.position = "";
            thead.style.top = "";
            thead.style.zIndex = "";
        } else {
            console.log("No <thead> element found in the target table.");
        }
    } else {
        console.log(`No table  found.`);
    }
}

// Function to reduce the table into a more readable view
function makeTableReadable() {
    const tables = document.querySelector('[class~="table"]');

    if (tables) {
        const tbody = tables.querySelector("tbody");

        if (tbody) {
            const rows = tbody.querySelectorAll("tr");

            // First, unhide all rows
            rows.forEach((row) => {
                row.style.display = ""; // Reset row visibility
            });

            // Then, hide rows based on the current NamesToHide list
            rows.forEach((row, index) => {
                const firstCell = row.querySelector("td");
                if (firstCell) {
                    // Normalize InputValue: Trim, convert to lowercase, and replace non-breaking spaces
                    const InputValue = firstCell.textContent
                        .trim()
                        .toLowerCase()
                        .replace(/\u00A0/g, " ");

                    NamesToHide.forEach((name) => {
                        const normalizedName = name
                            .trim()
                            .toLowerCase()
                            .replace(/\u00A0/g, " ");

                        if (normalizedName === InputValue) {
                            console.log(`Match found: "${normalizedName}" matches "${InputValue}"`);
                            row.style.display = "none"; // Hide matching row
                        } else {
                            console.log(`No match: "${normalizedName}" does not match "${InputValue}"`);
                            // compareStrings(normalizedName, InputValue); // Perform detailed comparison
                        }
                    });
                }
            });
        }
    }
}

// Helper function to compare strings character by character
function compareStrings(str1, str2) {
    const normalize = (str) => str.replace(/\u00A0/g, " "); // Replace non-breaking spaces
    str1 = normalize(str1);
    str2 = normalize(str2);

    const lengthDifference = str1.length - str2.length;
    const maxLength = Math.max(str1.length, str2.length);

    console.log(`Comparing strings:\nString 1: "${str1}"\nString 2: "${str2}"`);

    for (let i = 0; i < maxLength; i++) {
        const char1 = str1[i] || "(none)"; // Handle shorter string
        const char2 = str2[i] || "(none)"; // Handle shorter string

        if (char1 !== char2) {
            console.log(`Difference at index ${i}: "${char1}" vs "${char2}"`);
        }
    }

    if (lengthDifference !== 0) {
        console.log(`Length difference: String 1 has ${Math.abs(lengthDifference)} ${lengthDifference > 0 ? "more" : "fewer"} characters.`);
    } else {
        console.log("The strings are of the same length.");
    }
}


// Function to develop table into full view
function makeTableUnreadable() {
    // Find the table with the specified name attribute
    const tables = document.querySelector('[class~="table"]');

    if (tables) {
        // Find the first <tbody> inside the table
        const tbody = tables.querySelector("tbody");

        if (tbody) {
            //Now loop over all <tr>. Only interested in the first element.
            const rows = tbody.querySelectorAll('tr');
            rows.forEach((row, index) => {
                row.style.display ="";
                
        });

        }
    } 
}

//These lines add event listeners which upon receiving the message that the buttons have been pressed, do some stuff.
// Reapply saved settings when the content script loads
chrome.storage.local.get(["feature1", "feature2"], (result) => {
    if (result.feature1) {
        enableFeature1();
    }

    if (result.feature2) {
        enableFeature2();
    }
});

// Listen for messages from the popup or background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "updateFeatures") {
        console.log("Received updateFeatures message:", message);

        // Apply changes based on the new state
        if (message.feature1) {
            enableFeature1();
        } else {
            disableFeature1();
        }

        if (message.feature2) {
            enableFeature2();
        } else {
            disableFeature2();
        }
        }
        if (message.type === "updateNames") {
            NamesToHide = message.NamesToHide.map((name) => name.trim().toLowerCase());
            console.log("Updated Names to hide:", NamesToHide);
            makeTableReadable();
            sendResponse({ success: true });

            // Respond to indicate the changes have been applied
            sendResponse({ success: true });
    }
});

function enableFeature1() {
    console.log("Feature 1 enabled!");
    makeTableHeaderSticky();
}

function disableFeature1() {
    console.log("Feature 1 disabled!");
    makeTableHeaderUnsticky();
}

function enableFeature2() {
    console.log("Feature 2 enabled!");
    makeTableReadable();
}

function disableFeature2() {
    console.log("Feature 2 disabled!");
    makeTableUnreadable();
}