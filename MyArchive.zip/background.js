// Listens for messages from the popup and forwards them to the content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "updateFeatures") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, { feature1: message.feature1, feature2: message.feature2 });
            }
        });
    }
});