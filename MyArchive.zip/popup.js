// Load saved preferences and names on popup load
document.addEventListener("DOMContentLoaded", () => {
    chrome.storage.local.get(["feature1", "feature2", "NamesToHide"], (result) => {
        // Set feature toggles
        document.getElementById("feature1").checked = result.feature1 || false;
        document.getElementById("feature2").checked = result.feature2 || false;

        // Render names list
        const names = result.NamesToHide || [];
        renderNamesList(names);
    });
});

// Save feature toggles
document.getElementById("save").addEventListener("click", () => {
    const feature1 = document.getElementById("feature1").checked;
    const feature2 = document.getElementById("feature2").checked;

    chrome.storage.local.set({ feature1, feature2 }, () => {
        console.log("Preferences saved!");
        notifyContentScript({ type: "updateFeatures", feature1, feature2 });
    });
});

// Add a new name to the list
document.getElementById("addName").addEventListener("click", () => {
    const newName = document.getElementById("newName").value.trim();
    if (newName) {
        chrome.storage.local.get("NamesToHide", (result) => {
            const names = result.NamesToHide || [];
            names.push(newName);

            chrome.storage.local.set({ NamesToHide: names }, () => {
                console.log("New name added:", newName);
                renderNamesList(names);
                notifyContentScript({ type: "updateNames", NamesToHide: names });
            });
        });

        document.getElementById("newName").value = ""; // Clear input
    }
});

// Render the names list in the popup
function renderNamesList(names) {
    const namesList = document.getElementById("namesList");
    namesList.innerHTML = ""; // Clear existing list

    names.forEach((name, index) => {
        const listItem = document.createElement("li");

        // Editable input for the name
        const input = document.createElement("input");
        input.type = "text";
        input.value = name;
        input.addEventListener("change", () => {
            names[index] = input.value.trim();
            chrome.storage.local.set({ NamesToHide: names }, () => {
                console.log("Name updated:", names[index]);
                notifyContentScript({ type: "updateNames", NamesToHide: names });
            });
        });

        // Delete button for the name
        const deleteButton = document.createElement("button");
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", () => {
            names.splice(index, 1);
            chrome.storage.local.set({ NamesToHide: names }, () => {
                console.log("Name deleted:", name);
                renderNamesList(names);
                notifyContentScript({ type: "updateNames", NamesToHide: names });
            });
        });

        // Append input and button to the list item
        listItem.appendChild(input);
        listItem.appendChild(deleteButton);
        namesList.appendChild(listItem);
    });
}

// Notify the content script of updates
function notifyContentScript(message) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
                if (chrome.runtime.lastError) {
                    console.error("Error sending message to content script:", chrome.runtime.lastError);
                } else {
                    console.log("Response from content script:", response);
                }
            });
        }
    });
}